##############################################################################
# The following code can be used to match results between Whole Exome        #
#  Sequencing (WES) and Open Array (OA) panels to confirm sample             #
#  identity, aiding in sample tracking and tracing.                          #
# The inputs required are a VCF file data, a text file directly from the OA, #
#  and the sample name.                                                      # 
##############################################################################

#set the work directory in the fold "Tracking tool" !!modify the fold path!!
setwd("C:/Users/Admin/Desktop/Sample Tracking Tool")

# If the readxl library is not installed, install it
if (!requireNamespace("readxl", quietly = TRUE)) {
  install.packages("readxl")
}

# If the dplyr library is not installed, install it
if (!requireNamespace("dplyr", quietly = TRUE)) {
  install.packages("dplyr")
}

# If the openxlsx library is not installed, install it
if (!requireNamespace("openxlsx", quietly = TRUE)) {
  install.packages("openxlsx")
}

# If the vcfR library is not installed, install and load it
if (!requireNamespace("vcfR", quietly = TRUE)) {
  install.packages("vcfR")
}

# Load necessary libraries
library(readxl)
library(dplyr)
library(openxlsx)
library(vcfR)

########### ------------> Specify here the paths for your input files <---------------###########

file_path <- "Input/OA_ST_TWG53_26-01-2024.txt"
sample <- "NS-1895"
vcf_file <- "Input/NS1895.filtered.vcf.gz"

######################################################################################################
# This part of the code will create a template file with readable OA results for the specific sample #
######################################################################################################

# Read the content of the text file
file_content <- readLines(file_path)

# Find the line that contains the specified sample
sample_lines <- grep(paste0("^", sample, "\\s+"), file_content, ignore.case = TRUE)

# Extract lines related to the specified sample
sample_data <- file_content[sample_lines[1]:sample_lines[length(sample_lines)]]

# Remove empty or commented lines
sample_data <- sample_data[sample_data != "" & !grepl("^#", sample_data)]

# Create a dataframe from the extracted data
sample_df <- read.table(text = sample_data, header = FALSE, fill = TRUE)

# Assign names to columns
colnames(sample_df) <- c("SAMPLE", "PLATE", "PROBE", "FLR1", "FLR2")

# Read the second Excel file
second_file_path <- "Data/PANEL.xlsx"
second_data <- read.xlsx(second_file_path)

# Merge based on the "PROBE" column
merged_df <- merge(sample_df, second_data, by = "PROBE", all.x = TRUE)

# Reorder columns as desired
merged_df <- merged_df %>%
  select("SAMPLE", "PLATE", "PROBE", "FLR1", "FLR2", "CHR", "POS", "VIC", "FAM")

# Create a new Excel file with the name "Template_SAMPLE"
excel_file <- write.xlsx(merged_df, paste0("Template_OA/Template_", sample, "_OA", ".xlsx"), rowNames = FALSE)


########################################################################
# Match the Template file from OA with the VCF file from exome analysis#
########################################################################

# Manually specify the Excel file path
excel_file_path <- paste0("Template_OA/Template_", sample, "_OA", ".xlsx")

# Load and modify data from the compressed VCF file
vcf_data_vcfR <- read.vcfR(vcf_file)
vcf_data <- as.data.frame(getFIX(vcf_data_vcfR))
vcf_data <- as.data.frame(vcf_data_vcfR@fix)
colnames(vcf_data) <- c("CHR", "POS", "ID", "REF", "ALT", "QUAL", "FILTER", "ZygosityVCF")
vcf_data$ZygosityVCF <- sapply(strsplit(as.character(vcf_data$ZygosityVCF), ";"), function(x) x[1])

# Read the Template excel file
excel_data <- readxl::read_excel(excel_file_path)

# Create a new column in the Excel file based on the condition
excel_data$ZygosityOA <- ifelse(excel_data$FLR1== excel_data$FLR2, "Homozygous", "Heterozygous")

# Merge data based on "POS" and "CHR" columns
merged_data <- merge(excel_data, vcf_data, by.x = c("POS", "CHR"), by.y = c("POS", "CHR"), all.x = TRUE)

# Replace "AC=2" with "Homozygous" in ZygosityVCF column
merged_data$ZygosityVCF <- gsub("AC=2", "Homozygous", merged_data$ZygosityVCF)

# Replace "AC=1" with "Heterozygous" in ZygosityVCF column
merged_data$ZygosityVCF <- gsub("AC=1", "Heterozygous", merged_data$ZygosityVCF)

# Create a new column "Match"
merged_data$Match <- ifelse(merged_data$ZygosityOA == merged_data$ZygosityVCF, "Match", "No Match")
#merged_data$Match <- ifelse((merged_data$ZygosityOA == merged_data$ZygosityVCF) | (merged_data$ZygosityOA == "Homozygous" & merged_data$ZygosityVCF == "Hemizygous") , "Match", "No Match")

# Filter records with "NA" in the "ZygosityVCF" column
merged_data_na_filter <- merged_data[is.na(merged_data$ZygosityVCF), ]

# Filter records with non-"NA" values in the "ZygosityVCF" column
merged_data_not_na_filter <- merged_data[!is.na(merged_data$ZygosityVCF), ]

# Create columns "CALL_1" and "CALL_2"
merged_data_not_na_filter <- merged_data_not_na_filter %>%
  mutate(CALL_1 = ifelse(FLR1 == "FAM", FAM, VIC),
         CALL_2 = ifelse(FLR2 == "FAM", FAM, VIC)) 

# Specify the path for the second Excel file
freq_file <- "Data/AllFrequencies.xlsx"

# Read the second Excel file
freq_data <- readxl::read_excel(freq_file, sheet = "FREQUENCE")

merged_data_not_na_filter <- merged_data_not_na_filter %>%
  mutate(AllFr_Call1 = ifelse(FLR1 == "FAM", freq_data$FrAll_FAM, freq_data$FrAll_VIC),
         AllFr_Call2 = ifelse(FLR2 == "FAM", freq_data$FrAll_FAM, freq_data$FrAll_VIC))

# Convert columns to numeric type
try({
  merged_data_not_na_filter$AllFr_Call1 <- as.numeric(as.character(merged_data_not_na_filter$AllFr_Call1))

# Tratta i valori non numerici come NA
  merged_data_not_na_filter$AllFr_Call1[!is.finite(merged_data_not_na_filter$AllFr_Call1)] <- NA
})


try({
  merged_data_not_na_filter$AllFr_Call2 <- as.numeric(as.character(merged_data_not_na_filter$AllFr_Call2))
  # Tratta i valori non numerici come NA
  merged_data_not_na_filter$AllFr_Call2[!is.finite(merged_data_not_na_filter$AllFr_Call1)] <- NA
})

# Create "FrGenotypic" column
merged_data_not_na_filter$GenotypeFr <- ifelse(
  merged_data_not_na_filter$Match == "No Match", 1,
  ifelse(
    merged_data_not_na_filter$Match == "Match" & merged_data_not_na_filter$ZygosityVCF == "Homozygous",
    merged_data_not_na_filter$AllFr_Call1 * merged_data_not_na_filter$AllFr_Call2,
    ifelse(
      merged_data_not_na_filter$Match == "Match" & merged_data_not_na_filter$ZygosityVCF == "Heterozygous",
      merged_data_not_na_filter$AllFr_Call1 * merged_data_not_na_filter$AllFr_Call2 * 2,
      NA
    )
  )
)

# Reorganize columns
merged_data_not_na_filter <- merged_data_not_na_filter %>%
  select (CHR, POS, SAMPLE, PROBE, FLR1, FLR2, CALL_1, CALL_2, VIC, FAM, ZygosityOA, REF, ALT, FILTER, ZygosityVCF, Match, AllFr_Call1, AllFr_Call2, GenotypeFr)

# Specify the name of the output Excel file
excel_output_file <- "output.xlsx"

# Create the Excel file
wb <- createWorkbook()

# Add the sheet with ZygosityVCF non-"NA"
addWorksheet(wb, sheetName = "MERGE")
writeData(wb, sheet = "MERGE", x = merged_data_not_na_filter)

# Add the sheet with ZygosityVCF = "NA"
addWorksheet(wb, sheetName = "NO MERGE")
writeData(wb, sheet = "NO MERGE", x = merged_data_na_filter)

# Save the Excel file
saveWorkbook(wb, excel_output_file)

# Read the temporary output
read_sheet_MERGE <- read.xlsx("output.xlsx", sheet = "MERGE")
read_sheet_no_MERGE <- read.xlsx("output.xlsx", sheet = "NO MERGE")

# Initialize a new Workbook
wb_new <- createWorkbook()

# Specify the full path of the output file"
output_file_path <- "C:/Users/Admin/Desktop/Tracking Tool/output.xlsx"

# Add a style for cells with the 'Match' condition"
sheet_name_MERGE <- "MERGE"
addWorksheet(wb_new, sheet_name_MERGE)

# Add a style for cells with the 'Match' condition"
condition_green <- read_sheet_MERGE$Match == "Match"
for (row in which(condition_green)) {
  for (col in 1:ncol(read_sheet_MERGE)) {
    addStyle(wb_new, sheet = sheet_name_MERGE, row = row + 1, col = col,
             style = createStyle(fontColour = "black", fgFill = "lightgreen"))
  }
}

# Add a style for cells with the 'No Match' condition"
condition_red <- read_sheet_MERGE$Match == "No Match"
for (row in which(condition_red)) {
  for (col in 1:ncol(read_sheet_MERGE)) {
    addStyle(wb_new, sheet = sheet_name_MERGE, row = row + 1, col = col,
             style = createStyle(fontColour = "black", fgFill = "lightcoral"))
  }
}

# Add the new 'Check' column only when condition_red is true"
read_sheet_MERGE <- read_sheet_MERGE %>%
  mutate(Check = ifelse(condition_red, "Da controllare su IGV", "OK"))

# Create a new sheet NO MERGE
sheet_name_no_MERGE <- "NO MERGE"
addWorksheet(wb_new, sheet_name_no_MERGE)

# Add a style for cells with the 'Homozygous' condition"
condition_green <- read_sheet_no_MERGE$ZygosityOA == "Homozygous"
for (row in which(condition_green)) {
  for (col in 1:ncol(read_sheet_no_MERGE)) {
    addStyle(wb_new, sheet = sheet_name_no_MERGE, row = row + 1, col = col,
             style = createStyle(fontColour = "black", fgFill = "lightgreen"))
  }
}

# Add a style for cells with the "Heterozygous" condition" 
condition_red <- (read_sheet_no_MERGE$ZygosityOA == "Heterozygous") | (read_sheet_no_MERGE$FLR1 == "UND") | (read_sheet_no_MERGE$FLR2 == "UND")
for (row in which(condition_red)) {
  for (col in 1:ncol(read_sheet_no_MERGE)) {
    addStyle(wb_new, sheet = sheet_name_no_MERGE, row = row + 1, col = col,
             style = createStyle(fontColour = "black", fgFill = "lightcoral"))
  }
}

# Add the new 'Check' column only when condition_red is true
read_sheet_no_MERGE <- read_sheet_no_MERGE %>%
  mutate(Check = ifelse(condition_red, "Da controllare su IGV", "OK"))

# Load the existing Workbook" (output.xlsx)
wb_existing <- loadWorkbook("output.xlsx")

# "Copy the 'MERGE' sheet from the existing Workbook to the new Workbook"
writeData(wb_new, sheet = sheet_name_MERGE, x = read_sheet_MERGE)

# "Copy the 'NO MERGE' sheet from the existing Workbook to the new Workbook"
writeData(wb_new, sheet = sheet_name_no_MERGE, x = read_sheet_no_MERGE)

# "Save the new Workbook"
saveWorkbook(wb_new, paste0("C:/Users/Admin/Desktop/Tracking Tool/Results/MATCH_file_", sample, ".xlsx"), overwrite = TRUE)

file.remove("output.xlsx")

##############################################

